class System:
    def __init__(self, brand, model, serial_number, price):
        self.brand = brand
        self.model = model
        self.serial_number = serial_number
        self.price = price

    def display(self):
        print(f"Brand: {self.brand}")
        print(f"Model: {self.model}")
        print(f"Serial Number: {self.serial_number}")
        print(f"Price: ${self.price:.2f}")


class Server(System):
    def __init__(self, brand, model, serial_number, price, admin_username, ip_address):
        super().__init__(brand, model, serial_number, price)
        self.admin_username = admin_username
        self.ip_address = ip_address

    def display(self):
        super().display()
        print(f"Admin Username: {self.admin_username}")
        print(f"IP Address: {self.ip_address}")


class Client(System):
    def __init__(self, brand, model, serial_number, price, office_location, assigned_employee):
        super().__init__(brand, model, serial_number, price)
        self.office_location = office_location
        self.assigned_employee = assigned_employee

    def display(self):
        super().display()
        print(f"Office Location: {self.office_location}")
        print(f"Assigned Employee: {self.assigned_employee}")


system1 = System("Apple", "MacBook Air", "SN54321", 1199.99)
server1 = Server("HP", "ProLiant", "SN12345", 5999.99, "sysadmin", "10.0.0.1")
client1 = Client("Acer", "Aspire", "SN98765", 799.99, "Office B", "Alice Johnson")



print("System 1:")
system1.display()
print("\nServer 1:")
server1.display()
print("\nClient 1:")
client1.display()
