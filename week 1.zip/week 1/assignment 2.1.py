# 2.1.1 
def Input(prompt):
   
    user_input = input(prompt)
    return int(user_input)  

def Calculate(weight, height):
    BMI = weight / (height * height / 10000)  # Calculate BMI
    return BMI

weight = Input("Please input your weight (in kilograms): ")
height = Input("Please input your height (in centimeters): ")

bmi_result = Calculate(weight, height)

print(f"Your BMI is: {bmi_result:.2f}")

if bmi_result <= 18.5:
    print("you are underweight")

elif 18.5 <= bmi_result <= 24.9:
    print("you are Normal weight " )

elif 25 <= bmi_result <= 29.9:
    print("you are overweight")
elif bmi_result >= 30: 
    print("you are obese!!!") 

# 2.1.2
def Input(prompt):
    user_input = input(prompt)
    return float(user_input)  # Use float to handle decimal values as well

def calculate():
    num1 = Input("Please input first numeric value: ")
    num2 = Input("Please input second numeric value: ")
    what = input("Input what you want to do, sum, sub, multi, divide: ")
    
    if what == "sum":
        result = num1 + num2
    elif what == "sub":
        result = num1 - num2
    elif what == "multi":
        result = num1 * num2
    elif what == "divide":
        result = num1 / num2
    else:
        print("Invalid input")
        return

calculate()

# 2.1.3

def Input(prompt):
   
    user_input = input(prompt)
    return int(user_input)



def calculate():
    num1 = Input("Please input first numeric value :")
    num2 = Input("Please input second numeric value :")
  
    third_value = input("Do you want to enter a third numeric value? (yes/no): ").lower()
    if third_value == "yes":
        num3 = Input("Please input the third numeric value: ")
        operation = input("Input what you want to do with the third value, sum, sub, multi, divide: ")
        if operation == "sum":
            print(num1 + num2 + num3)
        elif operation == "sub":
            print(num1 - num2 - num3)
        elif operation == "multi":
            print(num1 * num2 * num3)
        elif operation == "divide":
            print(num1 / num2 / num3)

    elif third_value == "no":
        what = input("input what you want to do, sum, sub, multi, divide : ")
        if what == "sum":
            print(num1 + num2)
        elif what == "sub":
            print(num1 - num2)
        elif what == "multi":
            print(num1 * num2)
        elif what == "divide":
            print(num1 / num2)
        elif what != "sum, sub, multi, divide":
            print("invalide input") 
    calculate()

        
calculate()
    




#2.2.1
num_rows = int(input("Enter the number of rows: "))

for i in range(1, num_rows + 1):
   print(i * "*")

   

#2.2.2
def is_prime():
    number = int(input("input a number :"))
    
    if number <= 1:
        print("is_prime(", number , ")")
        print(False) 
    elif number <= 3:
        print("is_prime(", number , ")")
        print(True) 
    
    elif number % 2 == 0 or number % 3 == 0:
        print("is_prime(", number , ")")
        print(False) 
    
   
    i = 5
    while i * i <= number:
        if number % i == 0 or number % (i + 2) == 0:
            print("is_prime(", number , ")")
            print(False) 
        i += 6
    
        print(True) 

is_prime()



#2.2.3
def is_prime(num):
    if num <= 1:
        return False
    if num <= 3:
        return True
    if num % 2 == 0 or num % 3 == 0:
        return False
    i = 5
    while i * i <= num:
        if num % i == 0 or num % (i + 2) == 0:
            return False
        i += 6
    return True

def print_primes_up_to_n(n):
    for i in range(2, n + 1):
        if is_prime(i):
            print(i, end=' ')


n = int(input("Enter a number: "))
print("Prime numbers from 0 to", n, "are:")
print_primes_up_to_n(n)


#2.3.1
def Izan():
    names = []
    
    while True:
        namesadd = input("Input names (or press Enter to finish): ")
        
        if namesadd == "":
            break
        
        what = input("Add name? (yes/no): ")
        
        if what == "yes":
            names.append(namesadd)
        elif what == "no":
            pass  
        else:
            print("Wrong input, please try again.")
    
    if len(names) > 0:
        names.sort(reverse=True)
        print("Names in descending order:")
        for name in names:
            print(name)
    else:
        print("No names entered.")

Izan()

#2.3.2

def yimesh():
    
    n = int(input("Enter an integer: "))
    squares = [i ** 2 for i in range(n + 1)]
    print(squares)

yimesh()

#2.3.3 
def is_odd(number):
    return number % 2 != 0

def main():
    original = []
    modified = []
    
    while True:
        value = input("Enter a number (or 'done' to finish): ")
        
        if value == 'done':
            break
        
        try:
            number = int(value)
            original.append(number)
            modified.append(number)
            
            if is_odd(number):
                modified.remove(number)
                continue
            
                
        except ValueError:
            print("Invalid input Try again (or 'done' to finish): ")
    
    print("Original list:", original)
    

    print("modified list:", modified)

main()
